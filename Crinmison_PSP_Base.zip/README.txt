CRINMISON PSP - BASE JOGAVEL

Conteudo:
- src/main.c: loop principal, controle, gravidade, pulo, camera e animacoes.
- assets/sprites/: PNGs preparados em 128x128 com transparencia.
- Makefile: compilacao com PSPSDK, GU e libpng.

Controles:
- Direcional esquerda/direita: mover
- X: pular
- R + direcional: correr
- Quadrado: ataque
- Circulo: magia

Instalacao no PSP/PPSSPP:
Coloque EBOOT.PBP e a pasta assets dentro de PSP/GAME/Crinmison/.

As imagens originais foram recortadas pela area transparente e reduzidas com vizinho mais proximo para preservar o pixel art.
