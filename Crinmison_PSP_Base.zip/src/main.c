#include <pspkernel.h>
#include <pspdisplay.h>
#include <pspgu.h>
#include <pspgum.h>
#include <pspctrl.h>
#include <pspiofilemgr.h>
#include <png.h>
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include <setjmp.h>

PSP_MODULE_INFO("Crinmison", 0, 1, 0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);

#define SCREEN_W 480
#define SCREEN_H 272
#define BUF_W 512
#define PLAYER_W 64.0f
#define PLAYER_H 80.0f
#define FLOOR_Y 224.0f
#define GRAVITY 820.0f
#define JUMP_SPEED -330.0f
#define TEX_SIZE 128

typedef struct { float u,v,x,y,z; } Vertex;
typedef struct { unsigned int *pixels; int loaded; } Texture;
typedef enum { ANIM_IDLE, ANIM_WALK, ANIM_RUN, ANIM_JUMP, ANIM_FALL, ANIM_LANDING, ANIM_ATTACK, ANIM_HURT, ANIM_MAGIC } Anim;

typedef struct {
    float x,y,vx,vy;
    int grounded, facing, running;
    Anim anim;
    int frame;
    float anim_time, action_time;
} Player;

static unsigned int __attribute__((aligned(16))) list[262144];
static Texture textures[9][4];
static const char *paths[9][4] = {
 {"idle/idle_1.png",NULL,NULL,NULL},
 {"walk/walk_1.png","walk/walk_2.png",NULL,NULL},
 {"run/run_1.png","run/run_2.png","run/run_3.png","run/run_4.png"},
 {"jump/jump_1.png","jump/jump_2.png",NULL,NULL},
 {"fall/fall.png",NULL,NULL,NULL},
 {"landing/landing.png",NULL,NULL,NULL},
 {"attack/attack_1.png","attack/attack_2.png",NULL,NULL},
 {"hurt/hurt.png",NULL,NULL,NULL},
 {"magic/magic.png",NULL,NULL,NULL}
};
static const int frame_count[9]={1,2,4,2,1,1,2,1,1};

static FILE *open_asset(const char *relative) {
    char path[256]; FILE *f;
    const char *roots[]={"ms0:/PSP/GAME/Crinmison/assets/sprites/","ef0:/PSP/GAME/Crinmison/assets/sprites/","assets/sprites/"};
    for(int i=0;i<3;i++){ snprintf(path,sizeof(path),"%s%s",roots[i],relative); f=fopen(path,"rb"); if(f) return f; }
    return NULL;
}

static int load_png(Texture *tex,const char *relative) {
    FILE *fp=open_asset(relative); if(!fp) return 0;
    png_structp png=png_create_read_struct(PNG_LIBPNG_VER_STRING,NULL,NULL,NULL);
    if(!png){fclose(fp);return 0;}
    png_infop info=png_create_info_struct(png);
    if(!info){png_destroy_read_struct(&png,NULL,NULL);fclose(fp);return 0;}
    if(setjmp(png_jmpbuf(png))){png_destroy_read_struct(&png,&info,NULL);fclose(fp);return 0;}
    png_init_io(png,fp); png_read_info(png,info);
    png_uint_32 w,h; int depth,color; png_get_IHDR(png,info,&w,&h,&depth,&color,NULL,NULL,NULL);
    if(w>TEX_SIZE || h>TEX_SIZE){png_destroy_read_struct(&png,&info,NULL);fclose(fp);return 0;}
    if(depth==16) png_set_strip_16(png);
    if(color==PNG_COLOR_TYPE_PALETTE) png_set_palette_to_rgb(png);
    if(color==PNG_COLOR_TYPE_GRAY && depth<8) png_set_expand_gray_1_2_4_to_8(png);
    if(png_get_valid(png,info,PNG_INFO_tRNS)) png_set_tRNS_to_alpha(png);
    if(color==PNG_COLOR_TYPE_GRAY || color==PNG_COLOR_TYPE_GRAY_ALPHA) png_set_gray_to_rgb(png);
    if(!(color&PNG_COLOR_MASK_ALPHA)) png_set_add_alpha(png,0xff,PNG_FILLER_AFTER);
    png_read_update_info(png,info);
    png_size_t rowbytes=png_get_rowbytes(png,info);
    unsigned char *rgba=(unsigned char*)malloc(rowbytes*h);
    png_bytep *rows=(png_bytep*)malloc(sizeof(png_bytep)*h);
    if(!rgba||!rows){free(rgba);free(rows);png_error(png,"out of memory");}
    for(png_uint_32 y=0;y<h;y++) rows[y]=rgba+y*rowbytes;
    png_read_image(png,rows);
    tex->pixels=(unsigned int*)memalign(16,TEX_SIZE*TEX_SIZE*4);
    if(!tex->pixels){free(rgba);free(rows);png_error(png,"out of memory");}
    memset(tex->pixels,0,TEX_SIZE*TEX_SIZE*4);
    int ox=(TEX_SIZE-(int)w)/2, oy=(TEX_SIZE-(int)h)/2;
    for(png_uint_32 y=0;y<h;y++) memcpy((unsigned char*)tex->pixels+((oy+y)*TEX_SIZE+ox)*4,rows[y],w*4);
    tex->loaded=1;
    free(rgba);free(rows);png_destroy_read_struct(&png,&info,NULL);fclose(fp);return 1;
}

static void load_all_textures(void){
 for(int a=0;a<9;a++) for(int f=0;f<frame_count[a];f++) load_png(&textures[a][f],paths[a][f]);
}

static void set_anim(Player *p,Anim a){ if(p->anim!=a){p->anim=a;p->frame=0;p->anim_time=0.0f;} }
static void draw_texture(Texture *t,float x,float y,float w,float h,int flip){
 if(!t->loaded)return;
 sceGuEnable(GU_TEXTURE_2D); sceGuTexMode(GU_PSM_8888,0,0,0); sceGuTexImage(0,TEX_SIZE,TEX_SIZE,TEX_SIZE,t->pixels);
 sceGuTexFunc(GU_TFX_MODULATE,GU_TCC_RGBA); sceGuTexFilter(GU_NEAREST,GU_NEAREST); sceGuTexWrap(GU_CLAMP,GU_CLAMP); sceGuTexScale(1.0f,1.0f); sceGuTexOffset(0.0f,0.0f);
 Vertex *v=(Vertex*)sceGuGetMemory(2*sizeof(Vertex));
 v[0].u=flip?128.0f:0.0f; v[0].v=0; v[0].x=x; v[0].y=y; v[0].z=0;
 v[1].u=flip?0.0f:128.0f; v[1].v=128.0f; v[1].x=x+w; v[1].y=y+h; v[1].z=0;
 sceGuColor(0xffffffff); sceGuDrawArray(GU_SPRITES,GU_TEXTURE_32BITF|GU_VERTEX_32BITF|GU_TRANSFORM_2D,2,0,v); sceGuDisable(GU_TEXTURE_2D);
}
static void draw_rect(float x,float y,float w,float h,unsigned int color){
 sceGuDisable(GU_TEXTURE_2D); sceGuColor(color);
 Vertex *v=(Vertex*)sceGuGetMemory(2*sizeof(Vertex));
 v[0].u=v[0].v=0;v[0].x=x;v[0].y=y;v[0].z=0;
 v[1].u=v[1].v=0;v[1].x=x+w;v[1].y=y+h;v[1].z=0;
 sceGuDrawArray(GU_SPRITES,GU_VERTEX_32BITF|GU_TRANSFORM_2D,2,0,v);
}

int main(void){
 sceCtrlSetSamplingCycle(0); sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);
 sceGuInit();
 sceGuStart(GU_DIRECT,list);
 sceGuDrawBuffer(GU_PSM_8888,(void*)0,BUF_W);
 sceGuDispBuffer(SCREEN_W,SCREEN_H,(void*)0x88000,BUF_W);
 sceGuDepthBuffer((void*)0x110000,BUF_W);
 sceGuOffset(2048-(SCREEN_W/2),2048-(SCREEN_H/2)); sceGuViewport(2048,2048,SCREEN_W,SCREEN_H);
 sceGuScissor(0,0,SCREEN_W,SCREEN_H); sceGuEnable(GU_SCISSOR_TEST); sceGuDisable(GU_DEPTH_TEST);
 sceGuShadeModel(GU_SMOOTH); sceGuClearColor(0xff171022); sceGuClearDepth(0); sceGuClear(GU_COLOR_BUFFER_BIT|GU_DEPTH_BUFFER_BIT);
 sceGuFinish(); sceGuSync(0,0); sceDisplayWaitVblankStart(); sceGuDisplay(GU_TRUE);
 load_all_textures();
 Player p={100.0f,FLOOR_Y-PLAYER_H,0,0,1,1,0,ANIM_IDLE,0,0,0};
 unsigned int old=0; unsigned int last=sceKernelGetSystemTimeLow();
 while(1){
  unsigned int now=sceKernelGetSystemTimeLow(); float dt=(now-last)/1000000.0f; last=now; if(dt>0.05f)dt=0.05f;
  SceCtrlData pad; sceCtrlReadBufferPositive(&pad,1); unsigned int b=pad.Buttons;
  int left=(b&PSP_CTRL_LEFT)!=0, right=(b&PSP_CTRL_RIGHT)!=0;
  p.running=(b&PSP_CTRL_RTRIGGER)!=0;
  if(left&&!right){p.vx=p.running?-180.0f:-110.0f;p.facing=-1;} else if(right&&!left){p.vx=p.running?180.0f:110.0f;p.facing=1;} else p.vx=0;
  if((b&PSP_CTRL_CROSS)&&!(old&PSP_CTRL_CROSS)&&p.grounded){p.vy=JUMP_SPEED;p.grounded=0;set_anim(&p,ANIM_JUMP);}
  if((b&PSP_CTRL_SQUARE)&&!(old&PSP_CTRL_SQUARE)){p.action_time=0.30f;set_anim(&p,ANIM_ATTACK);}
  if((b&PSP_CTRL_CIRCLE)&&!(old&PSP_CTRL_CIRCLE)){p.action_time=0.45f;set_anim(&p,ANIM_MAGIC);}
  old=b;
  p.x+=p.vx*dt; if(p.x<0)p.x=0; if(p.x>2000)p.x=2000;
  if(!p.grounded){p.vy+=GRAVITY*dt;p.y+=p.vy*dt;if(p.y>=FLOOR_Y-PLAYER_H){p.y=FLOOR_Y-PLAYER_H;p.vy=0;p.grounded=1;set_anim(&p,ANIM_LANDING);p.action_time=0.12f;}}
  if(p.action_time>0){p.action_time-=dt;if(p.action_time<=0){p.action_time=0;}}
  if(p.action_time>0 && p.anim==ANIM_ATTACK){} else if(p.action_time>0 && p.anim==ANIM_MAGIC){} else if(!p.grounded){set_anim(&p,p.vy<0?ANIM_JUMP:ANIM_FALL);} else if(p.anim==ANIM_LANDING && p.action_time>0){} else if(p.vx!=0){set_anim(&p,p.running?ANIM_RUN:ANIM_WALK);} else set_anim(&p,ANIM_IDLE);
  p.anim_time+=dt; float step=(p.anim==ANIM_RUN)?0.09f:0.16f;
  if(p.anim_time>=step){p.anim_time=0;p.frame=(p.frame+1)%frame_count[p.anim];}
  float camera=p.x-200.0f; if(camera<0)camera=0;
  sceGuStart(GU_DIRECT,list); sceGuClearColor(0xff171022); sceGuClear(GU_COLOR_BUFFER_BIT|GU_DEPTH_BUFFER_BIT);
  draw_rect(0,FLOOR_Y,SCREEN_W,SCREEN_H-FLOOR_Y,0xff30233c);
  draw_rect(0,FLOOR_Y-3,SCREEN_W,3,0xff8a557a);
  int a=(int)p.anim; int f=p.frame; if(!textures[a][f].loaded){a=ANIM_IDLE;f=0;}
  draw_texture(&textures[a][f],p.x-camera,p.y,PLAYER_W,PLAYER_H,p.facing<0);
  sceGuFinish(); sceGuSync(0,0); sceDisplayWaitVblankStart(); sceGuSwapBuffers();
 }
 sceGuTerm(); return 0;
}
